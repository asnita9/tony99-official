const menu = document.getElementById("menu");
const nav = document.getElementById("nav");
menu.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menu.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menu.setAttribute("aria-expanded", "false");
}));
document.getElementById("yes").addEventListener("click", () => {
  document.getElementById("agegate").classList.add("hidden");
});
document.getElementById("no").addEventListener("click", () => {
  window.location.replace("about:blank");
});
document.getElementById("year").textContent = new Date().getFullYear();