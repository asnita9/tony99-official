# TONY99 — Gaming Resource Center

Responsive static landing page built with HTML, CSS and vanilla JavaScript.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive layout and visual styling
- `script.js` — mobile navigation and age confirmation

## Preview locally
Open `index.html` in a browser, or use VS Code Live Server.

## Deploy with GitHub Pages
1. Open repository **Settings**.
2. Select **Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`, then save.

The website is an informational landing page. Check local laws and applicable requirements before publishing or linking to online gaming services.